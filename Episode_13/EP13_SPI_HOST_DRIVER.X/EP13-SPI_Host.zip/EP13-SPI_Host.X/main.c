/*
 * File:   main.c
 * Author: C52467
 *
 * Created on November 7, 2023, 9:55 AM
 */

#define F_CPU 4E6
#include <xc.h>
#include <util/delay.h>
#include "main_clk_ctrl.h"
#include "usart0_tx.h"
//#include <avr/ioavr64dd32.h>

uint8_t spi_data_send_high_byte = 0x00;
uint8_t spi_data_send_low_byte = 0x00;
uint8_t spi_data_recv = 0xFF;

// function prototypes
void SPI_Host_Init();
void SPI_Select_Client(void);
void SPI_Deselect_Client(void);
uint8_t SPI_Write_Byte(uint8_t);


int main(void) {
    // 4MHz Main CLK, no prescaler, no CLKOUT
    // parameters: Clock Selection, Freq select, Prescaler Enable, Prescaler Divider, Clock out, MSB first
    MainClkCtrl(CLKCTRL_CLKSEL_OSCHF_gc, CLKCTRL_FRQSEL_4M_gc, 0, CLKCTRL_PDIV_2X_gc, 0);
    
    USART_Init(USART_CMODE_ASYNCHRONOUS_gc, USART_PMODE_DISABLED_gc, USART_SBMODE_1BIT_gc, USART_CHSIZE_8BIT_gc);
    SPI_Host_Init();
    printf("Testing SPI Host:\n");
    
    SPI0.INTCTRL |= SPI_TXCIE_bm;
    
    
    while(1)    {
        //printf("Sending SPI data: %d\n", spi_data_recv);
        SPI_Select_Client();
        SPI_Write_Byte(spi_data_send_high_byte++);
        SPI_Write_Byte(spi_data_send_low_byte++);
        SPI_Deselect_Client();
        
        _delay_ms(1);  
    }
    return 0;
}

// SPI 1MHz CLK, Master mode, MODE 0 (Resting CLK = LOW, Sample data on Rising edge, Setup/Drive data out falling edge)
void SPI_Host_Init()   {
    // use PA4, PA5, PA6, PA7 as MOSI, MISO, SCK, _SS respectively
    PORTMUX.SPIROUTEA = PORTMUX_SPI0_DEFAULT_gc;    
    
    // Set MOSI, SCK, _SS as outputs. Set MISO as input
    PORTA.DIRSET = (PIN4_bm | PIN6_bm | PIN7_bm);    // SS is output from this host
    PORTA.DIRCLR = PIN5_bm;
    // Divide main clock (4MHz) by 4 to get 1MHz SPI CLK & Set this MCU as SPI Master/Host
    SPI0.CTRLA = SPI_PRESC_DIV4_gc | SPI_MASTER_bm;
    // Enable Buffer mode (1 Tx Buffer for Master/Host) and set to Mode 0 (Most common mode)
    SPI0.CTRLB = SPI_BUFEN_bm | SPI_MODE_0_gc;

    SPI0.CTRLA |= SPI_ENABLE_bm;
}

void SPI_Select_Client(void)    {
    // pull _SS LOW to begin transmission
    PORTA.OUTCLR = PIN7_bm;
}

void SPI_Deselect_Client(void)  {
    // pull _SS HIGH to end transmission
    PORTA.OUTSET = PIN7_bm;
}

uint8_t SPI_Write_Byte(uint8_t byte)    { 
    // Write byte to data register
    SPI0.DATA = byte;
    // check to see buffer is ready before transmitting next byte
    while(!(SPI0.INTFLAGS & SPI_IF_bm));
    
    return SPI0.DATA;
}