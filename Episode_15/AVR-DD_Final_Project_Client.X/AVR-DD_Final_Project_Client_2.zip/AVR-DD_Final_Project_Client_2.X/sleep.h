// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef SLEEP_H
#define	SLEEP_H

#include <xc.h>

// parameters: Sleep Mode, Sleep Enable
void SLEEP_Init(uint8_t, uint8_t);   

#endif	/* SLEEP_H */

